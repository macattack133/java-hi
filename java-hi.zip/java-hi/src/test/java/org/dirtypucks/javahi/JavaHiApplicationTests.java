package org.dirtypucks.javahi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaHiApplicationTests {

	@Test
	void contextLoads() {
	}

}
